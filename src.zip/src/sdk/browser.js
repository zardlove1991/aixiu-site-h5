export const oauth = (cbk) => {
  console.log('browser_auth')
  // window.router && window.router.replace('/login')
}
