// 全场景对应关系
export const fullSceneMap = {
  '1': ['视频', 'video'],
  '2': ['图片', 'picture'],
  '3': ['文字', 'text'],
  '4': ['音频', 'audio']
}
