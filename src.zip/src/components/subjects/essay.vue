<template lang="html">
  <div class="subject-essay-wrap">
    <!--题目的标题-->
    <div class="subject-type-wrap" v-if="mode === 'analysis' && data.type === 'essay' && data.remark.score">
      <!-- <h3 class="subject-type">
        <span class="score" v-show="data.score">{{`(${data.score}分)`}}</span>
      </h3> -->
      <!--问答题批阅得分提醒-->
      <div
        v-show="mode === 'analysis' && data.type === 'essay' && data.remark.score"
        class="essay-audio-score">{{`得${data.remark.score}分`}}</div>
    </div>
    <p class="subject-title">
      <span>{{`${data.index}.`}}</span>
      <span v-html="_dealHtmlLine(data.title)"></span>
      <span class="all-score" v-show="data.score">{{`(${data.typeTip}${data.score}分)`}}</span>
    </p>
    <!--题干的媒体数据-->
    <div class="media-wrap" v-for="(media,mediaKey) in data.annex" :key="mediaKey">
      <img v-if="mediaKey=='image' && media && media.length" :src="annexMedia(media)"  @click.stop="_setPreviewState" v-preview="annexMedia(media)" preview-nav-enable="false" class="my-img"/>
      <!--音频播放-->
      <my-audio
        v-if="mediaKey=='audio' && annexMedia(media)"
        class="my-audio"
        :limit-info="{ isLimit: false }"
        :src="annexMedia(media)">
      </my-audio>
      <!--视频播放-->
      <my-video v-if="mediaKey=='video' && annexMedia(media)" class="my-video" :poster="annexMedia(media).cover" :src="annexMedia(media).src"></my-video>
    </div>
    <!--题目的内容区域-->
    <template v-if="essayTempAnswerInfo">
      <!--表单编辑区域-->
      <div class="from-wrap">
        <div class="content-wrap" v-show="renderType === 'exam'">
          <textarea class="content" placeholder="点击输入你的答案" maxlength="300"
            :value = "essayTempAnswerInfo.text"
            @input="uploadText"
            @blur="dealKeyboard"
            v-show="renderType === 'exam'">
          </textarea>
        </div>
        <!--回答的内容信息-->
        <p class="answer-content" v-show="renderType === 'analysis'">
          <span v-show="_checkMedaiObjIsEmpty(essayTempAnswerInfo)">当前没有回答信息哦~</span>
          <span v-show="essayTempAnswerInfo.text">{{essayTempAnswerInfo.text}}</span>
        </p>
      </div>
      <!--答案解析-->
      <div class="answerinfo-wrap" v-if="mode === 'analysis'">
        <div class="answer-analysis">
          <h4 class="title">解析</h4>
          <p class="content" v-if="data.analysis" v-html="data.analysis"></p>
          <p class="content" v-else>暂无解析内容~</p>
          <!--目前还没有类别和正确率 暂时隐藏-->
          <div class="exam-types" v-show="data.point && data.point.length">
            <span class="tip">知识点</span>
            <span class="type" v-for="item in data.point" :key="item.id">{{item.name}}</span>
          </div>
        </div>
        <!--问答题的老师点评-->
        <div class="essay-markinfo-wrap" v-if="data.remark.score">
          <h4 class="title">点评</h4>
          <!--点评的老师信息先不展示-->
          <!-- <div class="teacher-info" v-show="data.remark.teacher.name">
            <img v-show="data.remark.teacher.avatar" :src="data.remark.teacher.avatar" class="icon" />
            <span class="name">{{data.remark.teacher.name}}</span>
          </div> -->
          <p class="markinfo" :class="{ 'empty-info': !data.remark.content.text }">
            <span v-show="_checkMedaiObjIsEmpty(data.remark.content)">此处无声胜有声~</span>
            <span v-show="data.remark.content.text">{{data.remark.content.text}}</span>
          </p>
          <!--图片展示-->
          <div class="mark-img-wrap" v-if="data.remark.content.image && data.remark.content.image.length">
            <img :src="src" class="mark-img"
              @click.stop="_setPreviewState"
              v-preview="src" preview-nav-enable="false"
              v-for="(src, index) in data.remark.content.image" :key="index"/>
          </div>
          <!--音频播放-->
          <div class="mark-audio-wrap" v-if="data.remark.content.audio && data.remark.content.audio.length">
            <my-audio  class="mark-audio" :src="data.remark.content.audio[0]"></my-audio>
          </div>
          <!--视频播放-->
          <div class="mark-video-wrap" v-if="data.remark.content.video && data.remark.content.video.length">
            <my-video class="mark-video"
              :poster="data.remark.content.video[0].cover"
              :src="data.remark.content.video[0].src">
            </my-video>
          </div>
        </div>
      </div>
    </template>
    <!--引入录音组件-->
    <my-record ref="myRecord" @start="_resetCurPageRecord" @finish="_dealEssayFromValue"></my-record>
  </div>
</template>

<script>
import SubItemMixin from '@/mixins/subject-item'
import SubjectMixin from '@/mixins/subject'
import MyRecord from '@/components/depence/record'

export default {
  name: 'essay-subject',
  mixins: [ SubItemMixin, SubjectMixin ],
  components: { MyRecord },
  created () {
    // 赋值当前问答题临时对象 -> 调用mixin的方法
    this._setTempEssayAnswerInfo()
  },
  methods: {
    dealKeyboard () {
      // 兼容滚动视图代码
      document.body.scrollTop = 0
      window.scrollTo(0, 0)
    }
  }
}
</script>

<style lang="scss">
@import "@/styles/components/subjects/essay.scss";
</style>
