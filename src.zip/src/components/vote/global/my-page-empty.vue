<template>
  <div :class="['my-page-empty-wrap', { light: darkMark === '2' }]">
    <div class="empty-img"></div>
    <p class="empty-tip">{{tip}}</p>
  </div>
</template>

<script>
export default {
  props: {
    tip: {
      type: String,
      default: ''
    },
    darkMark: {
      type: String,
      default: ''
    }
  }
}
</script>

<style lang="scss">
  @import "@/styles/index.scss";
  .my-page-empty-wrap {
    width: 100%;
    height: 80vh;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    .empty-img {
      width: 100%;
      height: px2rem(254px);
      background-repeat: no-repeat;
      background-position: 40% top;
      background-size: px2rem(327px) px2rem(254px);
      background-image: image-set(url('https://xzh5.hoge.cn/new-vote/images/vote_empty_icon@2x.png') 1x, url('https://xzh5.hoge.cn/new-vote/images/vote_empty_icon@3x.png') 2x);
    }
    .empty-tip {
      font-size: px2rem(32px);
      color: rgba(255, 255, 255, 0.4);
      margin-top: px2rem(20px);
    }
    &.light {
      .empty-img {
        background-image: url('~@/assets/vote/vote-empty-icon.png');
      }
      .empty-tip {
        color: rgba(0, 0, 0, 0.4);
      }
    }
  }
</style>
