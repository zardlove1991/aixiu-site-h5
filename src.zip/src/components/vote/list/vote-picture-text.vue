<template>
  <div class="image-work-list-wrap">
    <div v-for="(item, index) in workList"
      :class="['work-list-item', item.is_my ? 'my-wrap' : '']"
      @click.stop="jumpPage('votedetail', { worksId: item.id })"
      :key="index">
      <div class="work-poster-wrap" :class="imageRatio? 'vertical' : 'horizontal'"
        v-if="item.material.image && item.material.image.length">
        <img
          class="thumb-bg"
          :src="(item.material.image.length && item.material.image[0].url) + '?x-oss-process=image/resize,w_400'"
          object-fit="cover" />
        <div class="thumb-num" v-show="item.material.image_counts > 1">{{item.material.image_counts}}</div>
        <div :class="['poster-infos-wrap', item.is_my ? 'my-infos-wrap' : '']">
          <div class="info-number">
            <span v-show="item.is_my">我的 · </span>{{item.numbering}} · {{item.total_votes}}{{signUnit}}
          </div>
        </div>
      </div>
      <div class="work-title">{{item.name}}</div>
      <div class="work-desc">{{item.source}}</div>
      <div class="vote-btn-group">
        <vote-btn-group :remainVotes="remainVotes" :data="item" :index="index" @btn-click="btnClick($event, index)"></vote-btn-group>
      </div>
    </div>
  </div>
</template>

<script>
import VoteBtnGroup from '@/components/vote/global/vote-btn-group'

export default {
  props: {
    workList: {
      type: Array,
      default: () => {
        return []
      }
    },
    remainVotes: {
      type: Number,
      default: 0
    },
    signUnit: {
      type: String,
      default: '票'
    },
    detailInfo: {
      type: Object,
      default: () => {
        return {}
      }
    }
  },
  components: {
    VoteBtnGroup
  },
  data () {
    return {
      imageRatio: 0
    }
  },
  methods: {
    jumpPage (page, data) {
      this.$emit('jump-page', page, data)
    },
    btnClick (data, index) {
      this.$emit('trigger-work', data, index)
    }
  },
  watch: {
    detailInfo: {
      handler (v) {
        if (v) {
          let { rule: { page_setup: { image_ratio: imageRatio } } } = v
          if (imageRatio) {
            this.imageRatio = imageRatio
            console.log('有值！！！！！')
          } else {
            this.imageRatio = 0
          }
        }
        console.log('detailInfo:', v)
      },
      deep: true,
      immediate: true
    }
  }
}
</script>

<style lang="scss">
  @import "@/styles/index.scss";
  .image-work-list-wrap {
    display: flex;
    flex-wrap: wrap;
    box-sizing: border-box;
    .work-list-item {
      width: 50%;
      padding: px2rem(25px) px2rem(15px) px2rem(25px) px2rem(30px);
      &:nth-child(odd) {
        .thumb-bg img {
          background-image: url('//xzh5.hoge.cn/new-vote/images/work_list_bg1@2x.png');
        }
      }
      &:nth-child(even) {
        // padding-right: 0;
        padding: px2rem(25px) px2rem(30px) px2rem(25px) px2rem(15px);
        .thumb-bg img {
          background-image: url('//xzh5.hoge.cn/new-vote/images/work_list_bg2@2x.png');
        }
      }
      .work-poster-wrap {
        position: relative;
        width: 100%;
        height: 0px;
        border-radius: px2rem(4px);
        &.horizontal {
          padding-bottom: 100%;
        }
        &.vertical {
          padding-bottom: 140%;
          // height: calc((50vw - 1.40625rem)*5.6/4);
        }
        .thumb-bg {
          position: absolute;
          left: 0;
          top: 0;
          right: 0;
          bottom: 0;
          width: 100%;
          height: 100%;
          border-radius: px2rem(4px);
        }
        .thumb-num {
          position: absolute;
          right: px2rem(10px);
          bottom: px2rem(10px);
          width: px2rem(60px);
          height: px2rem(40px);
          box-sizing: border-box;
          display: flex;
          align-items: center;
          padding-left: px2rem(38px);
          border-radius: px2rem(2px);
          font-size: px2rem(18px);
          color: #fff;
          background: rgba(0,0,0,0.5) url('//xzh5.hoge.cn/new-vote/images/commvote_image_icon@3x.png') no-repeat 5px center / 9px 8px;
        }
        .poster-infos-wrap {
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: px2rem(40px);
          border-radius: 4px;
          .info-number {
            position: absolute;
            top: 0;
            left: 0;
            height: px2rem(40px);
            padding: 0 px2rem(17px);
            border-radius: px2rem(4px) 0px px2rem(32px) 0px;
            background-color: rgba(0, 0, 0, 0.7);
            color: #fff;
            @include font-dpr(11px);
          }
          &.my-infos-wrap .info-number {
            background-color: rgba(0, 0, 0, 0.7);
            // @include bg-color('btnColor');
          }
        }
      }
      .work-title {
        height: px2rem(50px);
        @include font-dpr(16px);
        @include font-color('fontColor');
        line-height: px2rem(50px);
        margin-top: px2rem(15px);
        margin-bottom: px2rem(8px);
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .work-desc {
        margin-bottom: px2rem(25px);
        @include font-dpr(14px);
        @include font-color('fontColor');
        opacity: 0.7;
        line-height: 1;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
    }
  }
</style>
